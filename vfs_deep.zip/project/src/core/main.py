print("Core started")
