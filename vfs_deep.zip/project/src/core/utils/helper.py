def hello(): return "Hi"
